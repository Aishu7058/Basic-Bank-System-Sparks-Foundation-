<!DOCTYPE html>
<html>
<head>
	<title>Transaction History</title>
</head>
<body>
<form action="disp.php" method="POST">
	<center><input type="submit" name="btn" value="Show"></center>
</form>
</body>
</html>