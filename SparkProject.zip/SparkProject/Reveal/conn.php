<?php
$dbh='localhost';
$dbn='sparks_bank';
$dbunm='root';
$dbp='';

$mysqli=mysqli_connect($dbh,$dbunm,$dbp,$dbn);

?>